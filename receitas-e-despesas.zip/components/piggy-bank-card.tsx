"use client"

import { useEffect, useState } from "react"
import {
  motion,
  useMotionValue,
  useTransform,
  animate,
} from "framer-motion"
import { PiggyBank, Plus, Minus, Target } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useFinance } from "@/lib/finance-store"
import { formatCurrency } from "@/lib/format"

function AnimatedCurrency({ value }: { value: number }) {
  const count = useMotionValue(0)
  const text = useTransform(count, (v) => formatCurrency(v))
  useEffect(() => {
    const controls = animate(count, value, { duration: 1, ease: "easeOut" })
    return controls.stop
  }, [value, count])
  return <motion.span>{text}</motion.span>
}

function ProgressRing({ progress }: { progress: number }) {
  const size = 180
  const stroke = 14
  const radius = (size - stroke) / 2
  const circumference = 2 * Math.PI * radius
  const clamped = Math.min(1, Math.max(0, progress))

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="color-mix(in oklch, var(--chart-4) 22%, transparent)"
          strokeWidth={stroke}
        />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="var(--chart-4)"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: circumference * (1 - clamped) }}
          transition={{ duration: 1.1, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <PiggyBank className="mb-1 h-6 w-6 text-[var(--chart-4)]" />
        <motion.span
          key={Math.round(clamped * 100)}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-2xl font-bold tabular-nums text-card-foreground"
        >
          {Math.round(clamped * 100)}%
        </motion.span>
        <span className="text-xs text-muted-foreground">da meta</span>
      </div>
    </div>
  )
}

export function PiggyBankCard({ index = 0 }: { index?: number }) {
  const { piggy, setPiggyGoal, depositPiggy, withdrawPiggy } = useFinance()
  const remaining = Math.max(0, piggy.goal - piggy.saved)
  const progress = piggy.goal > 0 ? piggy.saved / piggy.goal : 0
  const reached = remaining === 0 && piggy.goal > 0

  const [goalOpen, setGoalOpen] = useState(false)
  const [moveOpen, setMoveOpen] = useState(false)
  const [moveMode, setMoveMode] = useState<"deposit" | "withdraw">("deposit")
  const [goalInput, setGoalInput] = useState(String(piggy.goal))
  const [amountInput, setAmountInput] = useState("")

  const openMove = (mode: "deposit" | "withdraw") => {
    setMoveMode(mode)
    setAmountInput("")
    setMoveOpen(true)
  }

  const confirmGoal = () => {
    const v = Number(goalInput.replace(",", "."))
    if (!Number.isNaN(v)) setPiggyGoal(v)
    setGoalOpen(false)
  }

  const confirmMove = () => {
    const v = Number(amountInput.replace(",", "."))
    if (!Number.isNaN(v) && v > 0) {
      if (moveMode === "deposit") depositPiggy(v)
      else withdrawPiggy(v)
    }
    setMoveOpen(false)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.08, ease: "easeOut" }}
      className="rounded-2xl border border-border bg-card p-5 shadow-sm"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[color-mix(in_oklch,var(--chart-4)_15%,transparent)]">
            <PiggyBank className="h-[18px] w-[18px] text-[var(--chart-4)]" />
          </div>
          <div>
            <p className="text-sm font-semibold text-card-foreground">
              Cofrinho
            </p>
            <p className="text-xs text-muted-foreground">Meta de poupança</p>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="gap-1.5"
          onClick={() => {
            setGoalInput(String(piggy.goal))
            setGoalOpen(true)
          }}
        >
          <Target className="h-3.5 w-3.5" />
          Meta
        </Button>
      </div>

      <div className="mt-5 flex flex-col items-center gap-5 sm:flex-row sm:items-center sm:gap-6">
        <ProgressRing progress={progress} />

        <div className="flex-1 space-y-3 self-stretch">
          <div className="rounded-xl bg-[color-mix(in_oklch,var(--chart-4)_10%,transparent)] p-3">
            <p className="text-xs font-medium text-muted-foreground">
              Guardado
            </p>
            <p className="text-xl font-bold tabular-nums text-[var(--chart-4)]">
              <AnimatedCurrency value={piggy.saved} />
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl bg-secondary p-3">
              <p className="text-xs font-medium text-muted-foreground">Meta</p>
              <p className="text-sm font-semibold tabular-nums text-card-foreground">
                {formatCurrency(piggy.goal)}
              </p>
            </div>
            <div className="rounded-xl bg-secondary p-3">
              <p className="text-xs font-medium text-muted-foreground">
                {reached ? "Status" : "Falta"}
              </p>
              <p
                className="text-sm font-semibold tabular-nums"
                style={{
                  color: reached ? "var(--chart-2)" : "var(--chart-3)",
                }}
              >
                {reached ? "Concluída!" : formatCurrency(remaining)}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <Button
          variant="default"
          className="gap-1.5"
          onClick={() => openMove("deposit")}
        >
          <Plus className="h-4 w-4" />
          Guardar
        </Button>
        <Button
          variant="outline"
          className="gap-1.5"
          onClick={() => openMove("withdraw")}
          disabled={piggy.saved <= 0}
        >
          <Minus className="h-4 w-4" />
          Resgatar
        </Button>
      </div>

      <Dialog open={goalOpen} onOpenChange={setGoalOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Definir meta do cofrinho</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Label htmlFor="piggy-goal">Quanto você quer guardar?</Label>
            <Input
              id="piggy-goal"
              inputMode="decimal"
              value={goalInput}
              onChange={(e) => setGoalInput(e.target.value)}
              placeholder="0,00"
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setGoalOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={confirmGoal}>Salvar meta</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={moveOpen} onOpenChange={setMoveOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>
              {moveMode === "deposit"
                ? "Guardar no cofrinho"
                : "Resgatar do cofrinho"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Label htmlFor="piggy-amount">Valor</Label>
            <Input
              id="piggy-amount"
              inputMode="decimal"
              value={amountInput}
              onChange={(e) => setAmountInput(e.target.value)}
              placeholder="0,00"
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMoveOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={confirmMove}>
              {moveMode === "deposit" ? "Guardar" : "Resgatar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  )
}
