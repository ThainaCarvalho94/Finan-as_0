"use client"

import { motion, useMotionValue, useTransform, animate } from "framer-motion"
import { useEffect } from "react"
import { TrendingUp, TrendingDown, Wallet, type LucideIcon } from "lucide-react"
import { formatCurrency } from "@/lib/format"
import { cn } from "@/lib/utils"

type StatVariant = "receita" | "despesa" | "saldo"

const CONFIG: Record<
  StatVariant,
  { label: string; icon: LucideIcon; accent: string; ring: string }
> = {
  receita: {
    label: "Receitas",
    icon: TrendingUp,
    accent: "text-[var(--chart-2)]",
    ring: "bg-[color-mix(in_oklch,var(--chart-2)_15%,transparent)]",
  },
  despesa: {
    label: "Despesas",
    icon: TrendingDown,
    accent: "text-[var(--chart-3)]",
    ring: "bg-[color-mix(in_oklch,var(--chart-3)_15%,transparent)]",
  },
  saldo: {
    label: "Saldo",
    icon: Wallet,
    accent: "text-primary",
    ring: "bg-[color-mix(in_oklch,var(--color-primary)_15%,transparent)]",
  },
}

function AnimatedValue({ value }: { value: number }) {
  const count = useMotionValue(0)
  const rounded = useTransform(count, (v) => formatCurrency(v))

  useEffect(() => {
    const controls = animate(count, value, {
      duration: 1.1,
      ease: "easeOut",
    })
    return controls.stop
  }, [value, count])

  return <motion.span>{rounded}</motion.span>
}

export function StatCard({
  variant,
  value,
  delta,
  index = 0,
}: {
  variant: StatVariant
  value: number
  delta?: number
  index?: number
}) {
  const config = CONFIG[variant]
  const Icon = config.icon

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.08, ease: "easeOut" }}
      whileHover={{ y: -4 }}
      className="rounded-2xl border border-border bg-card p-5 shadow-sm"
    >
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-muted-foreground">
          {config.label}
        </span>
        <div
          className={cn(
            "flex h-9 w-9 items-center justify-center rounded-xl",
            config.ring,
          )}
        >
          <Icon className={cn("h-[18px] w-[18px]", config.accent)} />
        </div>
      </div>
      <p
        className={cn(
          "mt-4 text-2xl font-bold tracking-tight tabular-nums sm:text-3xl",
          variant === "saldo" && value < 0 ? "text-destructive" : "text-card-foreground",
        )}
      >
        <AnimatedValue value={value} />
      </p>
      {typeof delta === "number" && (
        <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
          <span
            className={cn(
              "font-semibold",
              delta >= 0 ? "text-[var(--chart-2)]" : "text-[var(--chart-3)]",
            )}
          >
            {delta >= 0 ? "+" : ""}
            {delta.toFixed(1)}%
          </span>
          vs. mês anterior
        </p>
      )}
    </motion.div>
  )
}
