"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { LayoutDashboard, ArrowLeftRight, Tags, Wallet } from "lucide-react"
import { cn } from "@/lib/utils"
import { DashboardView } from "@/components/views/dashboard-view"
import { TransactionsView } from "@/components/views/transactions-view"
import { CategoriesView } from "@/components/views/categories-view"

type View = "dashboard" | "transactions" | "categories"

const NAV: { id: View; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "transactions", label: "Transações", icon: ArrowLeftRight },
  { id: "categories", label: "Categorias", icon: Tags },
]

export function AppShell() {
  const [view, setView] = useState<View>("dashboard")

  return (
    <div className="min-h-screen bg-background lg:flex">
      {/* Sidebar desktop */}
      <aside className="sticky top-0 hidden h-screen w-64 flex-col gap-2 bg-sidebar p-5 lg:flex">
        <div className="mb-6 flex items-center gap-3 px-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Wallet className="h-5 w-5" />
          </div>
          <div>
            <p className="text-base font-semibold text-sidebar-foreground">
              Fluxo
            </p>
            <p className="text-xs text-sidebar-foreground/60">Controle financeiro</p>
          </div>
        </div>
        <nav className="flex flex-col gap-1">
          {NAV.map((item) => {
            const active = view === item.id
            return (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                className={cn(
                  "relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "text-sidebar-primary-foreground"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground",
                )}
              >
                {active && (
                  <motion.span
                    layoutId="nav-active"
                    className="absolute inset-0 rounded-xl bg-sidebar-primary"
                    transition={{ type: "spring", stiffness: 400, damping: 32 }}
                  />
                )}
                <item.icon className="relative h-[18px] w-[18px]" />
                <span className="relative">{item.label}</span>
              </button>
            )
          })}
        </nav>
      </aside>

      {/* Mobile top nav */}
      <div className="sticky top-0 z-30 flex items-center gap-2 border-b border-border bg-sidebar px-4 py-3 lg:hidden">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <Wallet className="h-4 w-4" />
        </div>
        <span className="mr-2 font-semibold text-sidebar-foreground">Fluxo</span>
        <nav className="ml-auto flex gap-1">
          {NAV.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={cn(
                "flex items-center justify-center rounded-lg p-2 transition-colors",
                view === item.id
                  ? "bg-sidebar-primary text-sidebar-primary-foreground"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent",
              )}
              aria-label={item.label}
            >
              <item.icon className="h-5 w-5" />
            </button>
          ))}
        </nav>
      </div>

      <main className="flex-1 px-4 py-6 sm:px-6 lg:px-10 lg:py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
          >
            {view === "dashboard" && <DashboardView />}
            {view === "transactions" && <TransactionsView />}
            {view === "categories" && <CategoriesView />}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  )
}
