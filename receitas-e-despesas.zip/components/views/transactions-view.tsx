"use client"

import { useMemo, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Plus, Pencil, Trash2, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { TransactionDialog } from "@/components/transaction-dialog"
import { useFinance } from "@/lib/finance-store"
import { formatCurrency, formatDate } from "@/lib/format"
import type { Transaction } from "@/lib/types"

export function TransactionsView() {
  const { transactions, categories, deleteTransaction } = useFinance()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<Transaction | null>(null)
  const [query, setQuery] = useState("")
  const [filterType, setFilterType] = useState<string>("todos")

  const catName = (id: string) =>
    categories.find((c) => c.id === id)?.name ?? "—"
  const catColor = (id: string) =>
    categories.find((c) => c.id === id)?.color ?? "#999"

  const filtered = useMemo(() => {
    return transactions
      .filter((t) => (filterType === "todos" ? true : t.type === filterType))
      .filter((t) => {
        if (!query.trim()) return true
        const q = query.toLowerCase()
        return (
          t.description.toLowerCase().includes(q) ||
          t.tag.toLowerCase().includes(q) ||
          catName(t.categoryId).toLowerCase().includes(q)
        )
      })
      .sort((a, b) => b.date.localeCompare(a.date))
  }, [transactions, filterType, query, categories])

  const openNew = () => {
    setEditing(null)
    setDialogOpen(true)
  }
  const openEdit = (t: Transaction) => {
    setEditing(t)
    setDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">
            Transações
          </h1>
          <p className="text-muted-foreground">
            Cadastre e gerencie suas receitas e despesas
          </p>
        </div>
        <Button onClick={openNew} className="gap-2">
          <Plus className="h-4 w-4" />
          Nova transação
        </Button>
      </header>

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar por descrição, tag ou categoria"
            className="pl-9"
          />
        </div>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="receita">Receitas</SelectItem>
            <SelectItem value="despesa">Despesas</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
        {/* Header desktop */}
        <div className="hidden grid-cols-[2fr_1.2fr_1fr_1fr_1fr_auto] gap-4 border-b border-border px-5 py-3 text-xs font-medium uppercase tracking-wide text-muted-foreground md:grid">
          <span>Descrição</span>
          <span>Categoria</span>
          <span>Tag</span>
          <span>Data</span>
          <span className="text-right">Valor</span>
          <span className="w-16 text-right">Ações</span>
        </div>
        <ul>
          <AnimatePresence initial={false}>
            {filtered.map((t) => (
              <motion.li
                key={t.id}
                layout
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="grid grid-cols-2 items-center gap-x-4 gap-y-1 border-b border-border px-5 py-3 text-sm last:border-0 md:grid-cols-[2fr_1.2fr_1fr_1fr_1fr_auto]"
              >
                <span className="font-medium text-card-foreground">
                  {t.description}
                </span>
                <span className="flex items-center gap-2 text-muted-foreground">
                  <span
                    className="inline-block h-2.5 w-2.5 rounded-full"
                    style={{ backgroundColor: catColor(t.categoryId) }}
                  />
                  {catName(t.categoryId)}
                </span>
                <span className="hidden md:block">
                  {t.tag ? (
                    <Badge variant="secondary" className="font-normal">
                      {t.tag}
                    </Badge>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                </span>
                <span className="hidden text-muted-foreground md:block">
                  {formatDate(t.date)}
                </span>
                <span
                  className="text-right font-semibold tabular-nums"
                  style={{
                    color:
                      t.type === "receita"
                        ? "var(--chart-2)"
                        : "var(--chart-3)",
                  }}
                >
                  {t.type === "receita" ? "+" : "-"}
                  {formatCurrency(t.amount)}
                </span>
                <span className="col-span-2 flex justify-end gap-1 md:col-span-1 md:w-16">
                  <button
                    onClick={() => openEdit(t)}
                    className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                    aria-label="Editar"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => deleteTransaction(t.id)}
                    className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                    aria-label="Excluir"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </span>
              </motion.li>
            ))}
          </AnimatePresence>
        </ul>
        {filtered.length === 0 && (
          <p className="py-12 text-center text-sm text-muted-foreground">
            Nenhuma transação encontrada.
          </p>
        )}
      </div>

      <TransactionDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editing={editing}
      />
    </div>
  )
}
