"use client"

import { motion } from "framer-motion"
import { StatCard } from "@/components/stat-card"
import { CashFlowChart } from "@/components/charts/cash-flow-chart"
import { CategoryDonut } from "@/components/charts/category-donut"
import { PiggyBankCard } from "@/components/piggy-bank-card"
import { useTotals, useCashFlowByMonth, useFinance } from "@/lib/finance-store"
import { formatCurrency, formatDate, monthLabel } from "@/lib/format"

export function DashboardView() {
  const totals = useTotals()
  const flow = useCashFlowByMonth()
  const { transactions, categories } = useFinance()

  const current = flow[flow.length - 1]
  const previous = flow[flow.length - 2]

  const deltaPct = (cur?: number, prev?: number) => {
    if (!prev || !cur) return undefined
    return ((cur - prev) / prev) * 100
  }

  const catName = (id: string) =>
    categories.find((c) => c.id === id)?.name ?? "—"
  const catColor = (id: string) =>
    categories.find((c) => c.id === id)?.color ?? "#999"

  const recent = transactions.slice(0, 6)

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold tracking-tight text-foreground text-balance">
          Dashboard financeiro
        </h1>
        <p className="text-muted-foreground">
          Visão geral de {current ? monthLabel(current.month) : ""} e histórico
          de fluxo de caixa
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard
          variant="receita"
          value={current?.receita ?? totals.receita}
          delta={deltaPct(current?.receita, previous?.receita)}
          index={0}
        />
        <StatCard
          variant="despesa"
          value={current?.despesa ?? totals.despesa}
          delta={deltaPct(current?.despesa, previous?.despesa)}
          index={1}
        />
        <StatCard
          variant="saldo"
          value={current?.saldo ?? totals.saldo}
          delta={deltaPct(current?.saldo, previous?.saldo)}
          index={2}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <CashFlowChart />
        </div>
        <div className="lg:col-span-2">
          <CategoryDonut />
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <PiggyBankCard />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.25 }}
          className="rounded-2xl border border-border bg-card p-5 shadow-sm lg:col-span-2"
        >
          <h2 className="mb-4 text-base font-semibold text-card-foreground">
            Transações recentes
          </h2>
          <ul className="divide-y divide-border">
            {recent.map((t, i) => (
              <motion.li
                key={t.id}
                initial={{ opacity: 0, x: 8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.04 }}
                className="flex items-center gap-3 py-3"
              >
                <span
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-xs font-semibold"
                  style={{
                    backgroundColor: `color-mix(in oklch, ${catColor(t.categoryId)} 18%, transparent)`,
                    color: catColor(t.categoryId),
                  }}
                >
                  {catName(t.categoryId).slice(0, 2).toUpperCase()}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-card-foreground">
                    {t.description}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {catName(t.categoryId)} · {formatDate(t.date)}
                  </p>
                </div>
                <span
                  className="text-sm font-semibold tabular-nums"
                  style={{
                    color:
                      t.type === "receita"
                        ? "var(--chart-2)"
                        : "var(--chart-3)",
                  }}
                >
                  {t.type === "receita" ? "+" : "-"}
                  {formatCurrency(t.amount)}
                </span>
              </motion.li>
            ))}
          </ul>
        </motion.div>
      </div>
    </div>
  )
}
