"use client"

import {
  createContext,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react"
import type { Category, Transaction, TransactionType } from "@/lib/types"

type Piggy = {
  goal: number
  saved: number
}

type FinanceContextValue = {
  categories: Category[]
  transactions: Transaction[]
  piggy: Piggy
  setPiggyGoal: (goal: number) => void
  depositPiggy: (amount: number) => void
  withdrawPiggy: (amount: number) => void
  addCategory: (data: Omit<Category, "id">) => void
  updateCategory: (id: string, data: Omit<Category, "id">) => void
  deleteCategory: (id: string) => void
  addTransaction: (data: Omit<Transaction, "id">) => void
  updateTransaction: (id: string, data: Omit<Transaction, "id">) => void
  deleteTransaction: (id: string) => void
}

const FinanceContext = createContext<FinanceContextValue | null>(null)

const uid = () => Math.random().toString(36).slice(2, 10)

const seedCategories: Category[] = [
  { id: "c1", name: "Salário", type: "receita", color: "#3b82f6" },
  { id: "c2", name: "Freelance", type: "receita", color: "#10b981" },
  { id: "c3", name: "Investimentos", type: "receita", color: "#06b6d4" },
  { id: "c4", name: "Moradia", type: "despesa", color: "#ef4444" },
  { id: "c5", name: "Alimentação", type: "despesa", color: "#f59e0b" },
  { id: "c6", name: "Transporte", type: "despesa", color: "#8b5cf6" },
  { id: "c7", name: "Lazer", type: "despesa", color: "#ec4899" },
  { id: "c8", name: "Saúde", type: "despesa", color: "#14b8a6" },
]

function buildSeedTransactions(): Transaction[] {
  const now = new Date()
  const txs: Transaction[] = []
  // Gera 6 meses de histórico
  for (let m = 5; m >= 0; m--) {
    const ref = new Date(now.getFullYear(), now.getMonth() - m, 1)
    const y = ref.getFullYear()
    const mm = String(ref.getMonth() + 1).padStart(2, "0")

    txs.push({
      id: uid(),
      description: "Salário mensal",
      categoryId: "c1",
      amount: 7500,
      date: `${y}-${mm}-05`,
      tag: "fixo",
      type: "receita",
    })
    txs.push({
      id: uid(),
      description: "Projeto freelance",
      categoryId: "c2",
      amount: 1200 + m * 180,
      date: `${y}-${mm}-12`,
      tag: "extra",
      type: "receita",
    })
    txs.push({
      id: uid(),
      description: "Dividendos",
      categoryId: "c3",
      amount: 420 + m * 30,
      date: `${y}-${mm}-15`,
      tag: "passivo",
      type: "receita",
    })
    txs.push({
      id: uid(),
      description: "Aluguel",
      categoryId: "c4",
      amount: 2200,
      date: `${y}-${mm}-10`,
      tag: "fixo",
      type: "despesa",
    })
    txs.push({
      id: uid(),
      description: "Supermercado",
      categoryId: "c5",
      amount: 950 + m * 40,
      date: `${y}-${mm}-08`,
      tag: "essencial",
      type: "despesa",
    })
    txs.push({
      id: uid(),
      description: "Combustível e app",
      categoryId: "c6",
      amount: 480,
      date: `${y}-${mm}-18`,
      tag: "essencial",
      type: "despesa",
    })
    txs.push({
      id: uid(),
      description: "Streaming e cinema",
      categoryId: "c7",
      amount: 260,
      date: `${y}-${mm}-22`,
      tag: "lazer",
      type: "despesa",
    })
    txs.push({
      id: uid(),
      description: "Farmácia",
      categoryId: "c8",
      amount: 180 + m * 15,
      date: `${y}-${mm}-25`,
      tag: "saúde",
      type: "despesa",
    })
  }
  return txs
}

export function FinanceProvider({ children }: { children: ReactNode }) {
  const [categories, setCategories] = useState<Category[]>(seedCategories)
  const [transactions, setTransactions] = useState<Transaction[]>(
    buildSeedTransactions,
  )
  const [piggy, setPiggy] = useState<Piggy>({ goal: 10000, saved: 3500 })

  const value = useMemo<FinanceContextValue>(
    () => ({
      categories,
      transactions,
      piggy,
      setPiggyGoal: (goal) =>
        setPiggy((prev) => ({ ...prev, goal: Math.max(0, goal) })),
      depositPiggy: (amount) =>
        setPiggy((prev) => ({
          ...prev,
          saved: Math.max(0, prev.saved + amount),
        })),
      withdrawPiggy: (amount) =>
        setPiggy((prev) => ({
          ...prev,
          saved: Math.max(0, prev.saved - amount),
        })),
      addCategory: (data) =>
        setCategories((prev) => [...prev, { ...data, id: uid() }]),
      updateCategory: (id, data) =>
        setCategories((prev) =>
          prev.map((c) => (c.id === id ? { ...data, id } : c)),
        ),
      deleteCategory: (id) =>
        setCategories((prev) => prev.filter((c) => c.id !== id)),
      addTransaction: (data) =>
        setTransactions((prev) => [{ ...data, id: uid() }, ...prev]),
      updateTransaction: (id, data) =>
        setTransactions((prev) =>
          prev.map((t) => (t.id === id ? { ...data, id } : t)),
        ),
      deleteTransaction: (id) =>
        setTransactions((prev) => prev.filter((t) => t.id !== id)),
    }),
    [categories, transactions, piggy],
  )

  return (
    <FinanceContext.Provider value={value}>{children}</FinanceContext.Provider>
  )
}

export function useFinance() {
  const ctx = useContext(FinanceContext)
  if (!ctx) throw new Error("useFinance precisa estar dentro de FinanceProvider")
  return ctx
}

export function useCashFlowByMonth() {
  const { transactions } = useFinance()
  return useMemo(() => {
    const map = new Map<
      string,
      { key: string; year: number; month: number; receita: number; despesa: number }
    >()
    for (const t of transactions) {
      const [y, m] = t.date.split("-").map(Number)
      const key = `${y}-${String(m).padStart(2, "0")}`
      if (!map.has(key)) {
        map.set(key, { key, year: y, month: m - 1, receita: 0, despesa: 0 })
      }
      const entry = map.get(key)!
      if (t.type === "receita") entry.receita += t.amount
      else entry.despesa += t.amount
    }
    return Array.from(map.values())
      .sort((a, b) =>
        a.year === b.year ? a.month - b.month : a.year - b.year,
      )
      .map((e) => ({ ...e, saldo: e.receita - e.despesa }))
  }, [transactions])
}

export function useTotals(type?: TransactionType) {
  const { transactions } = useFinance()
  return useMemo(() => {
    const receita = transactions
      .filter((t) => t.type === "receita")
      .reduce((s, t) => s + t.amount, 0)
    const despesa = transactions
      .filter((t) => t.type === "despesa")
      .reduce((s, t) => s + t.amount, 0)
    return { receita, despesa, saldo: receita - despesa }
  }, [transactions, type])
}
